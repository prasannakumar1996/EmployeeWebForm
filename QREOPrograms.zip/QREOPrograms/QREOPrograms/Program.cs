﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace QREOPrograms
{
    class Program
    {
        static void Main(string[] args)
        {
            // C# program to replace space with "_"
            Console.WriteLine("C# program to replace space with '_'");
            Console.WriteLine();

            string text = "Hello! How are you?";
            Console.WriteLine("Before replace: "+text);
            text = text.Replace(" ", "_");
            Console.Write("After replace: ");
            Console.WriteLine(text);

            Console.WriteLine("-------------------------------------------------------");

            Console.WriteLine("C# program to write an input as password");
            Console.WriteLine();
            Console.Write("Enter a name: ");
            Console.WriteLine("Entered input is: "+GetPassword());


            Console.WriteLine("-------------------------------------------------------");

            Console.WriteLine("C# program to find the no. of occurences in the string");
            Console.WriteLine();
            Console.Write("Enter a string: ");
            string str = Console.ReadLine().ToString();
            Console.Write("Enter character: ");
            char c = Console.ReadLine().ToCharArray()[0];

            Console.Write("No. of times the character is repeated: ");
            Console.WriteLine(StringCount(str, c));

        }

        //Method that writes an input as password and returns it
        private static string GetPassword()
        {
            StringBuilder sb = new StringBuilder();
            while (true)
            {
                ConsoleKeyInfo cki = Console.ReadKey(true);
                if (cki.Key == ConsoleKey.Enter)
                {
                    Console.WriteLine();
                    break;
                }

                if (cki.Key == ConsoleKey.Backspace)
                {
                    if (sb.Length > 0)
                    {
                        Console.Write("\b\0\b");
                        sb.Length--;
                    }

                    continue;
                }

                Console.Write('*');
                sb.Append(cki.KeyChar);
            }

            return sb.ToString();
        }


        
        // Method that return count of the given character in the string 
        public static int StringCount(string s, char c)
        {
            int count = 0;

            for (int i = 0; i < s.Length; i++)
            {
                // checking character in string 
                if (s[i] == c)
                    count++;
            }

            return count;
        }
        
    }
}
