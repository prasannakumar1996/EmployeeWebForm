﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace QREOApplication
{
    public partial class EmpInfo : System.Web.UI.Page
    {
        string CS = ConfigurationManager.ConnectionStrings["EmployeeContext"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {


                Calendar1.Visible = false;
                Calendar2.Visible = false;
                Calendar3.Visible = false;

                
                using (SqlConnection con = new SqlConnection(CS))
                {
                    SqlCommand cmd = new SqlCommand("Select distinct City from dbo.EmployeeInfo", con);
                    con.Open();
                    SqlDataReader rdr = cmd.ExecuteReader();
                    DropDownList1.DataTextField = "City";
                    DropDownList1.DataValueField = "City";
                    DropDownList1.DataSource = rdr;
                    DropDownList1.DataBind();
                    con.Close();


                    SqlCommand cmd2 = new SqlCommand("Select distinct Name,ID from dbo.EmployeeInfo", con);
                    con.Open();
                    SqlDataReader rdr2 = cmd2.ExecuteReader();

                    DropDownList3.DataTextField = "Name";
                    DropDownList3.DataValueField = "ID";
                    DropDownList3.DataSource = rdr2;
                    DropDownList3.DataBind();
                    
                    con.Close();


                    SqlCommand cmd3 = new SqlCommand("Select distinct ID from dbo.EmployeeInfo", con);
                    con.Open();
                    SqlDataReader rdr3 = cmd3.ExecuteReader();
                    DropDownList4.DataTextField = "ID";
                    DropDownList4.DataValueField = "ID";
                    DropDownList4.DataSource = rdr3;
                    DropDownList4.DataBind();
                    
                    con.Close();
                    

                    ListItem li = new ListItem("--Select Manager--", "-1");
                    DropDownList3.Items.Insert(0, li);

                    ListItem li2 = new ListItem("--Select ID--", "-1");
                    DropDownList4.Items.Insert(0, li2);

                    
                    ListItem li3 = new ListItem("--Select City--", "-1");
                    DropDownList1.Items.Insert(0, li3);

                }

                
            }
           
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar1.Visible)
            {
                Calendar1.Visible = false;
            }
            else
            {
                Calendar1.Visible = true;
            }
        }


        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar2.Visible)
            {
                Calendar2.Visible = false;
            }
            else
            {
                Calendar2.Visible = true;
            }
        }

        protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar3.Visible)
            {
                Calendar3.Visible = false;
            }
            else
            {
                Calendar3.Visible = true;
            }
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            TextBox1.Text = Calendar1.SelectedDate.ToShortDateString();
            Calendar1.Visible = false;
        }

        protected void Calendar2_SelectionChanged(object sender, EventArgs e)
        {
            TextBox2.Text = Calendar2.SelectedDate.ToShortDateString();
            Calendar2.Visible = false;
            TextAge.Text = (Math.Round(DateTime.Now.Subtract(Convert.ToDateTime(TextBox2.Text)).TotalDays / 364)).ToString();
        }

        protected void Calendar3_SelectionChanged(object sender, EventArgs e)
        {
            TextBox3.Text = Calendar3.SelectedDate.ToShortDateString();
            Calendar3.Visible = false;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            if (DropDownList4.SelectedIndex != 0)
            {
                Label1.Text = "";
                ButtonSave.Text = "Update";

                using (SqlConnection con = new SqlConnection(CS))
                {
                    SqlCommand cmd = new SqlCommand("Select ID, Name,Adddress, City, DateOfBirth, Age, Department, Manager, DOJ,DOL from dbo.EmployeeInfo where ID=" + DropDownList4.SelectedValue, con);
                    con.Open();
                    using (SqlDataReader sdr = cmd.ExecuteReader())
                    {
                        sdr.Read();
                        TextName.Text = sdr["Name"].ToString();
                        TextArea1.InnerText = sdr["Adddress"].ToString();
                        DropDownList1.SelectedValue = sdr["City"].ToString();

                        TextAge.Enabled = false;
                        if (sdr["DateOfBirth"] == null || sdr["DateOfBirth"].ToString() == "")
                        {
                            TextAge.Enabled = true;
                            TextBox2.Text = "";
                            TextAge.Text = sdr["Age"].ToString();
                            //TextAge.Text = (DateTime.Now.Subtract(Convert.ToDateTime(sdr["DateOfBirth"])).TotalDays*360).ToString();

                        }
                        else
                        {
                            TextBox2.Text = Convert.ToDateTime(sdr["DateOfBirth"]).ToString("MM/dd/yyyy");
                            TextAge.Text = (Math.Round(DateTime.Now.Subtract(Convert.ToDateTime(sdr["DateOfBirth"])).TotalDays / 364)).ToString();
                        }

                        DropDownList2.SelectedItem.Text = sdr["Department"].ToString();
                        DropDownList3.SelectedItem.Text = sdr["Manager"].ToString();

                        TextBox1.Text = Convert.ToDateTime(sdr["DOJ"]).ToString("MM/dd/yyyy");
                        TextBox3.Text = Convert.ToDateTime(sdr["DOL"]).ToString("MM/dd/yyyy");
                    }

                    con.Close();
                }
            }
            else
            {
                Label1.Text = "Please select an ID";
            }
            

        }

        protected void ButtonSave_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                if (DropDownList4.SelectedIndex != 0)
                {
                    using (SqlConnection con = new SqlConnection(CS))
                    {
                        string sqlQuery = string.Format("UPDATE dbo.EmployeeInfo set Name='" + TextName.Text + "',Adddress='" + TextArea1.InnerText + "',City='" + DropDownList1.SelectedItem.Text + "',DateOfBirth='" + TextBox2.Text + "',Age=" + TextAge.Text + ",Department='" + DropDownList2.SelectedItem.Text + "',Manager='" + DropDownList3.SelectedItem.Text + "',DOJ='" + TextBox1.Text + "',DOL='" + TextBox3.Text + "' where ID='" + DropDownList4.SelectedItem.Value + "'");

                        SqlCommand cmd = new SqlCommand(sqlQuery, con);
                        con.Open();
                        SqlDataReader rdr4 = cmd.ExecuteReader();

                        con.Close();

                    }
                }
                else
                {
                    using (SqlConnection con = new SqlConnection(CS))
                    {


                        string sqlQuery = string.Format("insert into dbo.EmployeeInfo (Name,Adddress, City, DateOfBirth, Age, Department, Manager, DOJ,DOL) Values (" + "'" +
                            TextName.Text + "','" + TextArea1.InnerText + "','" + DropDownList1.SelectedItem.Text + "','" + TextBox2.Text + "'," + TextAge.Text + ",'" +
                             DropDownList2.SelectedItem.Text + "','" + DropDownList3.SelectedItem.Text + "','" + TextBox1.Text + "','" + TextBox3.Text + "')");

                        SqlCommand cmd = new SqlCommand(sqlQuery, con);
                        con.Open();
                        SqlDataReader rdr4 = cmd.ExecuteReader();

                        con.Close();

                    }
                }
            }
            

            
                
        }

        protected void ButtonReset_Click(object sender, EventArgs e)
        {
            ListItem li = new ListItem("--Select Manager--", "-1");
            DropDownList3.Items.Insert(0, li);

            ListItem li2 = new ListItem("--Select ID--", "-1");
            DropDownList4.Items.Insert(0, li2);


            ListItem li3 = new ListItem("--Select City--", "-1");
            DropDownList1.Items.Insert(0, li3);

            TextName.Text = "";
            TextArea1.InnerText = "";
            DropDownList1.SelectedIndex = -1;
            TextAge.Enabled = false;
            TextBox2.Text = "";
            TextAge.Text = "";
            DropDownList2.SelectedIndex = -1;
            DropDownList3.SelectedIndex = -1;
            TextBox1.Text = "";
            TextBox3.Text = "";
        }

        protected void DropDownList4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(DropDownList4.SelectedIndex != 1)
            {
                ButtonSave.Text = "Update";
            }

        }
    }

}